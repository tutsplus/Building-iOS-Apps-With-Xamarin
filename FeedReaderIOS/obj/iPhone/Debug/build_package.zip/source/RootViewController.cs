using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;

using MonoTouch.Foundation;
using MonoTouch.UIKit;

namespace FeedReaderIOS
{
    public class RootViewController : UIViewController {
        private UITextField _urlField;
        private UIButton _addButton;
        private UITableView _tableView;

        private List<RssFeed> _feeds;

        public RootViewController( ) {
            _feeds = new List<RssFeed>( );
        }

        public override void ViewDidLoad( ) {
            base.ViewDidLoad( );

            Title = "Rss Feeds";

            View.BackgroundColor = UIColor.LightGray;

            var h = 31.0f;
            var w = View.Bounds.Width - 20;

            _urlField = new UITextField {
                Placeholder = "Enter a feed url",
                BorderStyle = UITextBorderStyle.RoundedRect,
                Frame = new RectangleF( 10, 75, w, h ),
            };

            _addButton = UIButton.FromType( UIButtonType.RoundedRect );
            _addButton.Frame = new RectangleF(10, 120, w, 44);
            _addButton.SetTitle("Add", UIControlState.Normal);

            _tableView = new UITableView {
                Frame = new RectangleF( 0, 180, View.Bounds.Width, View.Bounds.Height - 180 )
            };

            View.AddSubviews(_urlField, _addButton, _tableView);
        }
    }
}